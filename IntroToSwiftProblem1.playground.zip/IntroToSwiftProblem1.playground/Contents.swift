//Define the Problem: Sum between two numbers, a and b, inclusive

func sumBetweenTwoNumbers(a: Int, b: Int) -> Int {
    var sum: Int = 0
    
    let timeMeasure = ContinuousClock().measure {
        
        for num in a...b {
            sum += num
        }
    }
    print("\(timeMeasure) for result \(sum)")
    return sum
}

sumBetweenTwoNumbers(a: 1, b: 10)
sumBetweenTwoNumbers(a: 1, b: 100_000)


func calculateSumOptimized(minValue: Int, maxValue: Int) -> Double {
    var sum: Double = 0
    let doubleVal1 = Double(minValue)
    let doubleVal2 = Double(maxValue)
    let timeMeasure = ContinuousClock().measure {
        sum = (doubleVal1  + doubleVal2) / 2
        sum *= doubleVal2 - doubleVal1  + 1
    }
    print("\(timeMeasure) for \(sum)")
    return sum
}

calculateSumOptimized(minValue: 1, maxValue: 10)
calculateSumOptimized(minValue: 0, maxValue: 10)
calculateSumOptimized(minValue: 1, maxValue: 100_000)


//Numerical Data Types and their representation / max

var myInt: Int = Int.max

var myFloat: Float = 9223372036854775808

myFloat *= 100

print(myFloat)

var myDouble: Double = 9223372036854775808
myDouble = myDouble * 100
print(myDouble)

// Integer division auto rounds
var intValue = 5 / 2
print(intValue)



struct Creature {
    var name: String
    var description: String
    var isGood: Bool
    var magicPower: Int
    private var CreatureArray: [Creature] = []

    
    init(name: String, description: String, isGood: Bool, magicPower: Int) {
        self.name = name
        self.description = description
        self.isGood = isGood
        self.magicPower = magicPower
    }
    
    var ability: Int {
        fibonacciAbility(myInt: magicPower)
    }
    
    func fibonacciAbility (myInt: Int) -> Int{
        var newNum = 0
        var oldNum1 = 1
        var oldNum2 = 1
        if myInt == 0 {
            return 0
        } else if myInt == 1{
            return 1
        } else if myInt == 2 {
            return 1
        }
        for _ in 3...myInt{
            newNum = oldNum1 + oldNum2
            oldNum2 = oldNum1
            oldNum1 = newNum
        }
        return newNum
    }
    
    func describeCreatures (creatureArray: [Creature]) {
        for creature in creatureArray{
            print("Description: \(creature.description) ---- Ability \(creature.ability)")
        }
    }
    
    func interactWith (myCreature: Creature){
        switch(self.isGood, myCreature.isGood){
        case(true, true): print("All is well; we are friends!")
        case(true, false): print("Hello Friend! GRRRRRRRRR, IMMA GRAB YOU")
        case(false, true): print("GRRRRRRRRR, IMMA GRAB YOU! Hello Friend!")
        case(false, false): print("THIS IS SPARTAAAAAAAA")
        }
    }
}



